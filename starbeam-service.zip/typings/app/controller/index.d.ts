// This file is created by egg-ts-helper@1.25.8
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportCategory from '../../../app/controller/category';
import ExportHome from '../../../app/controller/home';
import ExportOpus from '../../../app/controller/opus';
import ExportProject from '../../../app/controller/project';
import ExportShoot from '../../../app/controller/shoot';
import ExportAdminAccess from '../../../app/controller/admin/access';
import ExportAdminLogin from '../../../app/controller/admin/login';
import ExportAdminMain from '../../../app/controller/admin/main';
import ExportAdminManager from '../../../app/controller/admin/manager';
import ExportAdminRole from '../../../app/controller/admin/role';

declare module 'egg' {
  interface IController {
    category: ExportCategory;
    home: ExportHome;
    opus: ExportOpus;
    project: ExportProject;
    shoot: ExportShoot;
    admin: {
      access: ExportAdminAccess;
      login: ExportAdminLogin;
      main: ExportAdminMain;
      manager: ExportAdminManager;
      role: ExportAdminRole;
    }
  }
}
