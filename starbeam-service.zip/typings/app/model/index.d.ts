// This file is created by egg-ts-helper@1.25.8
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportAccess from '../../../app/model/access';
import ExportAdmin from '../../../app/model/admin';
import ExportBanner from '../../../app/model/banner';
import ExportCategory from '../../../app/model/category';
import ExportOpus from '../../../app/model/opus';
import ExportProject from '../../../app/model/project';
import ExportRole from '../../../app/model/role';
import ExportRoleAccess from '../../../app/model/roleAccess';
import ExportShoot from '../../../app/model/shoot';

declare module 'egg' {
  interface IModel {
    Access: ReturnType<typeof ExportAccess>;
    Admin: ReturnType<typeof ExportAdmin>;
    Banner: ReturnType<typeof ExportBanner>;
    Category: ReturnType<typeof ExportCategory>;
    Opus: ReturnType<typeof ExportOpus>;
    Project: ReturnType<typeof ExportProject>;
    Role: ReturnType<typeof ExportRole>;
    RoleAccess: ReturnType<typeof ExportRoleAccess>;
    Shoot: ReturnType<typeof ExportShoot>;
  }
}
